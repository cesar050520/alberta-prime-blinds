# Alberta Prime Blinds v4 — Print and PDF repair

Builds as Android APK; updated native implementation of Print and Save PDF.

- **Print**: opens the Android print service on a separate loaded quotation WebView.
- **Save PDF**: Android ACTION_CREATE_DOCUMENT opens a file destination and writes an actual PDF through the WebView PrintDocumentAdapter.
- **Camera / gallery**: retains previous WebChromeClient and FileProvider flow.
- **Orders**: retains applicationId `ca.albertaprime.blinds` and IndexedDB `alberta-prime-blinds-v1` for compatibility.
- **Data safety**: builds signed with GitHub Actions' default debug key. Previous APK may have different signature: back up your orders before installing and do not uninstall until backed up.

## GitHub Actions

Upload the ZIP to the repository, then update workflow `Extract Android project` command to:

`unzip -q AlbertaPrimeBlinds_v4_Android_Source.zip -d android`

Ensure the Build APK step uses only `gradle --no-daemon :app:assembleDebug` (the PrintManager import is already fixed in this source).

## Verification

Static HTML/JS syntax and project ZIP structure validated. Actual Android Print/PDF and camera workflows need testing on-device.
