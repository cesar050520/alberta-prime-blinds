package ca.albertaprime.blinds;

import android.app.Activity;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PageRange;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ActivityNotFoundException;
import android.provider.MediaStore;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** An offline native Android container for the Alberta Prime quotations app. */
public class MainActivity extends Activity {
    private static final int PICK_PICTURE = 1001;
    private static final int SAVE_BACKUP = 1002;
    private static final int SAVE_PDF = 1003;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private Uri cameraUri;
    private String pendingBackup;
    // Keep the printable WebView alive while Android's print service renders its pages.
    private WebView printableWeb;
    private boolean pdfMode=false;
    private String printName="Alberta_Prime_Quotation";
    private boolean printReady=false;
    private boolean requestedSave=false;

    @SuppressWarnings("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4,42,37));
        getWindow().setNavigationBarColor(Color.rgb(4,42,37));
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String u=request.getUrl().toString();
                if (u.startsWith("file:///android_asset/")) return false;
                startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser=callback;
                try {
                    Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                    gallery.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] accepts=params.getAcceptTypes();
                    boolean isImage=accepts==null || accepts.length==0 || accepts[0]==null || accepts[0].isEmpty() || accepts[0].startsWith("image/");
                    gallery.setType(isImage ? "image/*" : "application/json");
                    if(!isImage){startActivityForResult(gallery,PICK_PICTURE);return true;}
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f=File.createTempFile("alberta_photo_", ".jpg",getCacheDir());
                    cameraUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);
                    camera.setClipData(ClipData.newRawUri("photo",cameraUri));
                    camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if (params.isCaptureEnabled()) {
                        try {
                            startActivityForResult(camera,PICK_PICTURE);
                        } catch(ActivityNotFoundException notFound) {
                            cameraUri=null;
                            startActivityForResult(gallery,PICK_PICTURE);
                        }
                    } else {
                        Intent intent=Intent.createChooser(gallery,"Select product / window photo");
                        intent.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera});
                        startActivityForResult(intent,PICK_PICTURE);
                    }
                    return true;
                } catch (Exception ex) {
                    if(chooser!=null)chooser.onReceiveValue(null);
                    chooser=null;
                    Toast.makeText(MainActivity.this,"Unable to open camera / gallery",Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
        web.addJavascriptInterface(new Object() {
            // Native Android printing: render only the quotation in a separate WebView.
            // The main app WebView must stay visible and must not be printed directly.
            @JavascriptInterface public void printQuoteHtml(String html,String requestedName,boolean preferPdf) {
                runOnUiThread(()->startQuotationPrint(html,requestedName,preferPdf));
            }
            @JavascriptInterface public void savePdfHtml(String html,String requestedName) {
                runOnUiThread(()->startQuotationPrint(html,requestedName,true));
            }
            @JavascriptInterface public void saveBackup(String name,String json) { runOnUiThread(()->{
                pendingBackup=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,name);
                startActivityForResult(i,SAVE_BACKUP);
            }); }
        },"AndroidApp");
        web.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes documentAttributes(){
        return new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("quotation","Quotation",300,300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR).build();
    }

    private void startQuotationPrint(String quotationHtml,String requestedName,boolean savePdf) {
        if(quotationHtml==null || quotationHtml.trim().isEmpty()) {
            Toast.makeText(this,"Quotation is empty",Toast.LENGTH_LONG).show();
            return;
        }
        pdfMode=savePdf;
        printReady=false;
        requestedSave=false;
        printName=(requestedName==null?"Alberta_Prime_Quotation":requestedName)
            .replaceAll("[^a-zA-Z0-9_. -]", "_");
        if(printName.isEmpty()) printName="Alberta_Prime_Quotation";
        Toast.makeText(this,savePdf?"Preparing PDF…":"Preparing print preview…",Toast.LENGTH_SHORT).show();
        try {
            if(printableWeb!=null) {printableWeb.stopLoading(); printableWeb.destroy();}
            printableWeb = new WebView(this);
            WebSettings settings=printableWeb.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDefaultTextEncodingName("UTF-8");
            printableWeb.setWebViewClient(new WebViewClient(){
                @Override public void onPageFinished(WebView view,String url){
                    // Give the image and style resources a chance to load before rendering PDF.
                    view.postDelayed(()->checkPrintResources(view,0),450);
                }
                @Override public void onReceivedError(WebView v, android.webkit.WebResourceRequest request,
                    android.webkit.WebResourceError error){
                    Log.w("PrimePrint","Resource failed: "+request.getUrl());
                }
            });
            String document="<!doctype html><html><head><meta charset='utf-8'>"+
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"+
                "<link rel='stylesheet' href='styles.css'>"+
                "<style>html,body{background:#fff!important;margin:0!important;}"+
                "#print-host{display:block!important;}"+
                ".sheet{width:100%;max-width:none;min-height:0;padding:6mm!important;box-shadow:none!important;}"+
                "@page{size:A4;margin:9mm}</style></head><body><div id='print-host'>"+
                quotationHtml+"</div></body></html>";
            printableWeb.loadDataWithBaseURL("file:///android_asset/",document,"text/html","UTF-8",null);
        }catch(Exception ex){
            Log.e("PrimePrint","Failed to prepare quotation",ex);
            Toast.makeText(this,"Could not prepare quotation: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void checkPrintResources(WebView view,int tries){
        if(view!=printableWeb || printReady)return;
        try {
            view.evaluateJavascript("(function(){return Array.from(document.images).every(function(i){return i.complete;})})()",done->{
                if(view!=printableWeb || printReady)return;
                if("true".equals(done) || tries>=20){
                    printReady=true;
                    if(pdfMode) requestPdfDestination();
                    else openAndroidPrint(view);
                }else view.postDelayed(()->checkPrintResources(view,tries+1),250);
            });
        }catch(Exception ex){
            Log.e("PrimePrint","Resource check failed",ex);
            printReady=true;
            if(pdfMode)requestPdfDestination(); else openAndroidPrint(view);
        }
    }

    private void openAndroidPrint(WebView view){
        try{
            PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
            if(manager==null)throw new IllegalStateException("Print service is unavailable");
            manager.print(printName,view.createPrintDocumentAdapter(printName),documentAttributes());
        }catch(Exception ex){
            Log.e("PrimePrint","Failed to launch Android printing",ex);
            Toast.makeText(this,"Print error: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void requestPdfDestination(){
        if(requestedSave)return;
        requestedSave=true;
        try{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE,printName+".pdf");
            startActivityForResult(i,SAVE_PDF);
        }catch(Exception ex){
            Log.e("PrimePrint","Cannot open Save PDF file picker",ex);
            Toast.makeText(this,"PDF save picker unavailable: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void writePdfToDestination(Uri destination){
        if(printableWeb==null || !printReady){
            Toast.makeText(this,"Quotation not ready; please try again",Toast.LENGTH_LONG).show();
            return;
        }
        final PrintDocumentAdapter adapter=printableWeb.createPrintDocumentAdapter(printName);
        final ParcelFileDescriptor fd;
        try{
            fd=getContentResolver().openFileDescriptor(destination,"w");
            if(fd==null)throw new IllegalStateException("Cannot open selected file");
        }catch(Exception ex){
            Toast.makeText(this,"Could not create PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show();
            return;
        }
        try{
            adapter.onStart();
            adapter.onLayout(null,documentAttributes(),new CancellationSignal(),
                new PrintDocumentAdapter.LayoutResultCallback(){
                    @Override public void onLayoutFinished(PrintDocumentInfo info,boolean changed){
                        try{
                            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES},fd,
                                new CancellationSignal(),new PrintDocumentAdapter.WriteResultCallback(){
                                    @Override public void onWriteFinished(PageRange[] pages){
                                        try{fd.close();}catch(Exception ignored){}
                                        adapter.onFinish();
                                        Toast.makeText(MainActivity.this,"PDF saved successfully",Toast.LENGTH_LONG).show();
                                    }
                                    @Override public void onWriteFailed(CharSequence error){
                                        try{fd.close();}catch(Exception ignored){}
                                        adapter.onFinish();
                                        Toast.makeText(MainActivity.this,"PDF save failed: "+error,Toast.LENGTH_LONG).show();
                                    }
                                    @Override public void onWriteCancelled(){
                                        try{fd.close();}catch(Exception ignored){}
                                        adapter.onFinish();
                                        Toast.makeText(MainActivity.this,"PDF save cancelled",Toast.LENGTH_SHORT).show();
                                    }
                                });
                        }catch(Exception ex){
                            Log.e("PrimePrint","PDF write failed",ex);
                            try{fd.close();}catch(Exception ignored){}
                            adapter.onFinish();
                            Toast.makeText(MainActivity.this,"PDF write error: "+ex.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    }
                    @Override public void onLayoutFailed(CharSequence error){
                        try{fd.close();}catch(Exception ignored){}
                        adapter.onFinish();
                        Toast.makeText(MainActivity.this,"PDF layout failed: "+error,Toast.LENGTH_LONG).show();
                    }
                    @Override public void onLayoutCancelled(){
                        try{fd.close();}catch(Exception ignored){}
                        adapter.onFinish();
                        Toast.makeText(MainActivity.this,"PDF layout cancelled",Toast.LENGTH_SHORT).show();
                    }
                },new Bundle());
        }catch(Exception ex){
            Log.e("PrimePrint","PDF layout crash",ex);
            try{fd.close();}catch(Exception ignored){}
            adapter.onFinish();
            Toast.makeText(this,"PDF error: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_PICTURE){
            if(chooser!=null){
                Uri uri=null;
                if(resultCode==RESULT_OK){
                    if(data!=null && data.getData()!=null)uri=data.getData();
                    else if(cameraUri!=null)uri=cameraUri;
                }
                chooser.onReceiveValue(uri==null?null:new Uri[]{uri});
                chooser=null;cameraUri=null;
            }
        } else if(requestCode==SAVE_PDF){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                writePdfToDestination(data.getData());
            }
        } else if(requestCode==SAVE_BACKUP){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackup!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Unable to open destination");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup saved",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"Backup save failed",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed(){
        web.evaluateJavascript("window.albertaBack ? window.albertaBack() : false",value->{
            if("false".equals(value))finish();
        });
    }
    @Override protected void onDestroy(){
        if(printableWeb!=null)printableWeb.destroy();
        if(web!=null)web.destroy();
        super.onDestroy();
    }
}
