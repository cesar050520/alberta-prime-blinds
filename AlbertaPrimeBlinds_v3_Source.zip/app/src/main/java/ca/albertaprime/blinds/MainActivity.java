package ca.albertaprime.blinds;

import android.app.Activity;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ActivityNotFoundException;
import android.provider.MediaStore;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** An offline native Android container for the Alberta Prime quotations app. */
public class MainActivity extends Activity {
    private static final int PICK_PICTURE = 1001;
    private static final int SAVE_BACKUP = 1002;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private Uri cameraUri;
    private String pendingBackup;
    // Keep the printable WebView alive while Android's print service renders its pages.
    private WebView printableWeb;

    @SuppressWarnings("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4,42,37));
        getWindow().setNavigationBarColor(Color.rgb(4,42,37));
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String u=request.getUrl().toString();
                if (u.startsWith("file:///android_asset/")) return false;
                startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser=callback;
                try {
                    Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                    gallery.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] accepts=params.getAcceptTypes();
                    boolean isImage=accepts==null || accepts.length==0 || accepts[0]==null || accepts[0].isEmpty() || accepts[0].startsWith("image/");
                    gallery.setType(isImage ? "image/*" : "application/json");
                    if(!isImage){startActivityForResult(gallery,PICK_PICTURE);return true;}
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f=File.createTempFile("alberta_photo_", ".jpg",getCacheDir());
                    cameraUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);
                    camera.setClipData(ClipData.newRawUri("photo",cameraUri));
                    camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if (params.isCaptureEnabled()) {
                        try {
                            startActivityForResult(camera,PICK_PICTURE);
                        } catch(ActivityNotFoundException notFound) {
                            cameraUri=null;
                            startActivityForResult(gallery,PICK_PICTURE);
                        }
                    } else {
                        Intent intent=Intent.createChooser(gallery,"Select product / window photo");
                        intent.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera});
                        startActivityForResult(intent,PICK_PICTURE);
                    }
                    return true;
                } catch (Exception ex) {
                    if(chooser!=null)chooser.onReceiveValue(null);
                    chooser=null;
                    Toast.makeText(MainActivity.this,"Unable to open camera / gallery",Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
        web.addJavascriptInterface(new Object() {
            // Native Android printing: render only the quotation in a separate WebView.
            // The main app WebView must stay visible and must not be printed directly.
            @JavascriptInterface public void printQuoteHtml(String html,String requestedName,boolean preferPdf) {
                runOnUiThread(()->startQuotationPrint(html,requestedName,preferPdf));
            }
            @JavascriptInterface public void saveBackup(String name,String json) { runOnUiThread(()->{
                pendingBackup=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,name);
                startActivityForResult(i,SAVE_BACKUP);
            }); }
        },"AndroidApp");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void startQuotationPrint(String quotationHtml,String requestedName,boolean preferPdf) {
        // The Android print UI supports both printers and "Save as PDF".
        // Android deliberately lets the user choose the output destination.
        final String cleanName = requestedName.replaceAll("[^a-zA-Z0-9_. -]", "_");
        try {
            if(printableWeb!=null) { printableWeb.stopLoading(); printableWeb.destroy(); }
            printableWeb = new WebView(this);
            WebSettings settings=printableWeb.getSettings();
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDefaultTextEncodingName("UTF-8");
            printableWeb.setWebViewClient(new WebViewClient() {
                private boolean launched=false;
                @Override public void onPageFinished(WebView view,String url) {
                    if(launched)return;
                    launched=true;
                    // Allow the company watermark, thumbnails and stylesheet to finish loading.
                    view.postDelayed(()->{
                        try {
                            PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                            if(pm==null)throw new IllegalStateException("Print service unavailable");
                            PrintAttributes attrs=new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                .build();
                            pm.print(cleanName,view.createPrintDocumentAdapter(cleanName),attrs);
                            if(preferPdf)Toast.makeText(MainActivity.this,
                                "Choose Save as PDF, then tap the save button",Toast.LENGTH_LONG).show();
                        } catch(Exception ex) {
                            Toast.makeText(MainActivity.this,"Unable to open Android printing",Toast.LENGTH_LONG).show();
                        }
                    },600);
                }
            });
            String document="<!doctype html><html><head><meta charset='utf-8'>"+
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"+
                "<link rel='stylesheet' href='styles.css'>"+
                "<style>html,body{background:#fff!important;margin:0!important;}"+
                "#print-host{display:block!important;}"+
                ".sheet{width:100%;max-width:none;min-height:0;padding:6mm 6mm!important;box-shadow:none!important;}"+
                "@page{size:A4;margin:9mm}</style></head><body><div id='print-host'>"+
                quotationHtml+"</div></body></html>";
            printableWeb.loadDataWithBaseURL("file:///android_asset/",document,"text/html","UTF-8",null);
        } catch (Exception ex) {
            Toast.makeText(this,"Could not prepare quotation",Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_PICTURE){
            if(chooser!=null){
                Uri uri=null;
                if(resultCode==RESULT_OK){
                    if(data!=null && data.getData()!=null)uri=data.getData();
                    else if(cameraUri!=null)uri=cameraUri;
                }
                chooser.onReceiveValue(uri==null?null:new Uri[]{uri});
                chooser=null;cameraUri=null;
            }
        } else if(requestCode==SAVE_BACKUP){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackup!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Unable to open destination");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup saved",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"Backup save failed",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed(){
        web.evaluateJavascript("window.albertaBack ? window.albertaBack() : false",value->{
            if("false".equals(value))finish();
        });
    }
    @Override protected void onDestroy(){
        if(printableWeb!=null)printableWeb.destroy();
        if(web!=null)web.destroy();
        super.onDestroy();
    }
}
