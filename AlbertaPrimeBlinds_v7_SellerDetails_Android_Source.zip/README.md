# Alberta Prime Blinds v7 — Editable Seller Details

Adds an editable **Seller Details** section under **More & Settings** to the v6 native-PDF source. Seller name, role, business/phone/email/address, website, GST/business number, notes, default terms and authorized-by name appear in the quote preview and Android PDF. Tap **Save Seller Info** to save. Existing quotes retain their original seller details; tap **Update Seller Details** on an existing quotation to refresh it intentionally.

The original offline data-store ID and Android package remain unchanged, but Android signing keys can vary between builds. **Export a backup before uninstalling any APK.**

The v6 native Save PDF and Print functions are included, but physical-device behavior is still unverified. This ZIP is Android source, not a compiled APK.

For the existing GitHub Actions repo, upload the ZIP and change the extract step to:

```yaml
      - name: Extract Android project
        run: unzip -q AlbertaPrimeBlinds_v7_SellerDetails_Android_Source.zip -d android
```

Keep Gradle and Android SDK steps unchanged. Build outputs `app/build/outputs/apk/debug/app-debug.apk`.
