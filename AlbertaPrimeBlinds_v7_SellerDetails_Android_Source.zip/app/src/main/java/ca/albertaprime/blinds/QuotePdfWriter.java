package ca.albertaprime.blinds;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Produces PDF pages directly using Android's PdfDocument (no hidden WebView or print UI dependency). */
public final class QuotePdfWriter {
    private static final int PAGE_W=595, PAGE_H=842;
    private static final float LEFT=38, RIGHT=557, BOTTOM=790;
    private static final int GREEN=Color.rgb(7,52,45);
    private static final int GOLD=Color.rgb(167,131,62);
    private static final int INK=Color.rgb(37,51,47);
    private static final int MUTED=Color.rgb(100,112,108);
    private static final int PALE=Color.rgb(246,245,240);
    private final PdfDocument pdf=new PdfDocument();
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Bitmap logo;
    private final JSONObject quote,settings,totals;
    private PdfDocument.Page page;
    private Canvas canvas;
    private int pageNo=0;
    private float y;

    private QuotePdfWriter(Context context,JSONObject root) throws Exception {
        quote=root.getJSONObject("quote");
        settings=root.optJSONObject("company");
        totals=root.optJSONObject("totals");
        Bitmap loaded;
        try(java.io.InputStream in=context.getAssets().open("assets/logo-transparent.png")){
            loaded=BitmapFactory.decodeStream(in);
        }
        logo=loaded;
    }

    public static byte[] create(Context context,String input) throws Exception {
        QuotePdfWriter writer=new QuotePdfWriter(context,new JSONObject(input));
        try {
            writer.build();
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            writer.pdf.writeTo(out);
            return out.toByteArray();
        }finally{
            writer.pdf.close();
            if(writer.logo!=null&&!writer.logo.isRecycled())writer.logo.recycle();
        }
    }

    private String s(JSONObject obj,String key){return obj==null?"":obj.optString(key,"");}
    private double n(JSONObject obj,String key){return obj==null?0:obj.optDouble(key,0);}
    private String money(double n){return String.format(Locale.CANADA,"$%,.2f",n);}
    private String clean(String s){return (s==null?"":s).replace('\n',' ').replace('\r',' ').trim();}

    private void color(int color){p.setColor(color);p.setAlpha(255);p.setStyle(Paint.Style.FILL);}
    private void rect(float l,float t,float r,float b,int color){color(color);canvas.drawRect(l,t,r,b,p);}
    private void line(float x,float a,float xx,float b,int color,float stroke){
        color(color);p.setStrokeWidth(stroke);canvas.drawLine(x,a,xx,b,p);
    }
    private void text(String value,float x,float yy,float size,int color,boolean bold){
        color(color);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));
        p.setTextSize(size);canvas.drawText(clean(value),x,yy,p);
    }
    private void rightText(String value,float x,float yy,float size,int c,boolean bold){
        color(c);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        String txt=clean(value);canvas.drawText(txt,x-p.measureText(txt),yy,p);
    }
    private List<String> wrap(String input,float maxWidth,float textSize,boolean bold){
        List<String> rows=new ArrayList<>();
        p.setTextSize(textSize);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        String content=clean(input);if(content.isEmpty()){rows.add("");return rows;}
        String current="";
        for(String word:content.split("\\s+")){
            String possible=current.isEmpty()?word:current+" "+word;
            if(p.measureText(possible)<=maxWidth){current=possible;}
            else{
                if(!current.isEmpty())rows.add(current);
                current=word;
                while(p.measureText(current)>maxWidth&&current.length()>1){
                    int split=p.breakText(current,true,maxWidth,null);
                    split=Math.max(1,split);
                    rows.add(current.substring(0,split));current=current.substring(split);
                }
            }
        }
        if(!current.isEmpty())rows.add(current);
        return rows;
    }
    private float paragraph(String txt,float x,float yy,float width,float size,int col,boolean bold,float leading,int maxRows){
        List<String> rows=wrap(txt,width,size,bold);
        int count=0;
        for(String part:rows){if(count>=maxRows)break;text(part,x,yy,size,col,bold);yy+=leading;count++;}
        return yy;
    }
    private void drawLogo(float x,float top,float w,float h,int alpha){
        if(logo==null)return;
        p.setColor(Color.WHITE);p.setAlpha(alpha);p.setFilterBitmap(true);
        canvas.drawBitmap(logo,null,new RectF(x,top,x+w,top+h),p);
        p.setAlpha(255);
    }

    private void newPage(){
        if(page!=null)finishPage();
        pageNo++;
        page=pdf.startPage(new PdfDocument.PageInfo.Builder(PAGE_W,PAGE_H,pageNo).create());
        canvas=page.getCanvas();
        canvas.drawColor(Color.WHITE);
        drawLogo(128,280,340,164,17);
        rect(0,0,PAGE_W,8,GREEN);
        y=45;
        text("ALBERTA PRIME SERVICES INC.",LEFT,32,10,GOLD,true);
        line(LEFT,40,RIGHT,40,GOLD,0.65f);
    }
    private void finishPage(){
        if(page==null)return;
        line(LEFT,803,RIGHT,803,Color.rgb(225,224,219),0.6f);
        text("Alberta Prime Services Inc.  •  Quotation",LEFT,819,8,MUTED,false);
        rightText("Page "+pageNo,RIGHT,819,8,MUTED,false);
        pdf.finishPage(page);page=null;canvas=null;
    }
    private void room(float needed){if(y+needed>BOTTOM)newPage();}

    private void build(){
        newPage();
        y=62;
        drawLogo(LEFT,y,220,106,255);
        text("QUOTATION",405,89,20,GOLD,true);
        String quoteNum=s(quote,"quoteNo");
        rightText(quoteNum,RIGHT,108,9,INK,true);
        rightText("Date: "+s(quote,"date"),RIGHT,124,9,MUTED,false);
        rightText("Valid until: "+s(quote,"validUntil"),RIGHT,140,9,MUTED,false);
        rightText("Status: "+s(quote,"status"),RIGHT,156,9,MUTED,false);
        line(LEFT,185,RIGHT,185,GOLD,2);
        y=207;
        text("PREPARED FOR",LEFT,y,10,GREEN,true);
        text(s(settings,"company"),314,y,10,GREEN,true);
        y+=21;
        float ya=paragraph(s(quote,"clientName"),LEFT,y,245,11,INK,true,16,3);
        ya=paragraph(s(quote,"phone"),LEFT,ya,245,9,MUTED,false,14,2);
        ya=paragraph(s(quote,"email"),LEFT,ya,245,9,MUTED,false,14,3);
        ya=paragraph(s(quote,"address"),LEFT,ya,245,9,MUTED,false,14,4);
        float yb=y;
        if(!s(settings,"sellerName").isEmpty())yb=paragraph("Seller: "+s(settings,"sellerName"),314,yb,239,10,INK,true,14,2);
        if(!s(settings,"sellerRole").isEmpty())yb=paragraph(s(settings,"sellerRole"),314,yb,239,9,MUTED,false,14,2);
        yb=paragraph(s(settings,"phone"),314,yb,239,9,MUTED,false,14,2);
        yb=paragraph(s(settings,"email"),314,yb,239,9,MUTED,false,14,2);
        yb=paragraph(s(settings,"address"),314,yb,239,9,MUTED,false,14,3);
        if(!s(settings,"website").isEmpty())yb=paragraph(s(settings,"website"),314,yb,239,9,MUTED,false,14,2);
        if(!s(settings,"businessNumber").isEmpty())yb=paragraph("GST / Business No: "+s(settings,"businessNumber"),314,yb,239,8,MUTED,false,12,2);
        if(!s(settings,"sellerNotes").isEmpty())yb=paragraph(s(settings,"sellerNotes"),314,yb,239,8,MUTED,false,12,3);
        y=Math.max(ya,yb)+25;
        room(45);
        String title=s(quote,"title");
        text(title.isEmpty()?"Your next project":title,LEFT,y,12,GOLD,true);y+=20;
        drawWindowRows();
        totalsBlock();
        String notes=s(quote,"notes");
        String terms=s(settings,"sellerTerms");
        if(!terms.isEmpty())notes=notes.isEmpty()?terms:notes+"   "+terms;
        if(!notes.isEmpty()){
            room(92);
            text("NOTES & TERMS",LEFT,y,10,GREEN,true);y+=18;
            for(String row:wrap(notes,500,9,false)){
                room(15);text(row,LEFT,y,9,INK,false);y+=15;
            }
        }
        room(55);
        y+=30;
        line(LEFT,y,285,y,Color.LTGRAY,0.8f);
        text("Client signature / Date",LEFT,y+14,8,MUTED,false);
        if(!s(settings,"authorizedBy").isEmpty())rightText("Authorized by: "+s(settings,"authorizedBy"),RIGHT,y+14,8,MUTED,false);
        finishPage();
    }
    private void drawWindowRows(){
        JSONArray windows=quote.optJSONArray("windows");
        if(windows==null)return;
        for(int i=0;i<windows.length();i++){
            JSONObject w=windows.optJSONObject(i);if(w==null)continue;
            boolean hasPhoto=!s(w,"referencePhoto").isEmpty()||!s(w,"blindsPhoto").isEmpty();
            float block=hasPhoto?155:97;
            room(block+10);
            rect(LEFT,y,RIGHT,y+25,PALE);
            text("WINDOW "+String.format(Locale.CANADA,"%02d",i+1),LEFT+8,y+17,10,GREEN,true);
            rightText(s(w,"room"),RIGHT-8,y+17,10,INK,true);
            y+=41;
            text(s(w,"productName"),LEFT+8,y,10,INK,true);
            rightText(money((n(w,"basePrice")+n(w,"controlPrice"))*Math.max(1,n(w,"qty"))),RIGHT-8,y,11,GREEN,true);
            y+=16;
            String measurements=s(w,"width")+" × "+s(w,"height")+" "+s(w,"unit");
            String control=s(w,"controlName");
            String info="Size: "+measurements+"   Qty: "+s(w,"qty")+"   "+(control.isEmpty()?"No control":control)+" • "+s(w,"controlSide");
            paragraph(info,LEFT+8,y,500,9,MUTED,false,13,3);y+=17;
            String detail=s(w,"fabric")+"  "+s(w,"mount");
            if(!detail.trim().isEmpty())text(detail,LEFT+8,y,9,MUTED,false);
            if(hasPhoto){
                y+=12;
                int drawn=0;
                Bitmap reference=readPhoto(s(w,"referencePhoto"));
                if(reference!=null){drawPicture(reference,LEFT+8,y,97,57);reference.recycle();drawn++;}
                Bitmap blinds=readPhoto(s(w,"blindsPhoto"));
                if(blinds!=null){drawPicture(blinds,LEFT+113,y,97,57);blinds.recycle();drawn++;}
                if(drawn>0)y+=59;
            }
            y+=23;line(LEFT,y,RIGHT,y,Color.rgb(228,228,222),0.6f);y+=23;
        }
    }
    private Bitmap readPhoto(String data){
        if(data==null||!data.startsWith("data:image/"))return null;
        try{
            int comma=data.indexOf(',');if(comma<0)return null;
            byte[] bytes=Base64.decode(data.substring(comma+1),Base64.DEFAULT);
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
            opts.inJustDecodeBounds=false;opts.inSampleSize=1;
            while(opts.outWidth/opts.inSampleSize>700||opts.outHeight/opts.inSampleSize>700)opts.inSampleSize*=2;
            return BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
        }catch(Exception e){return null;}
    }
    private void drawPicture(Bitmap bitmap,float x,float top,float width,float height){
        float scale=Math.min(width/bitmap.getWidth(),height/bitmap.getHeight());
        float w=bitmap.getWidth()*scale,h=bitmap.getHeight()*scale;
        color(Color.WHITE);canvas.drawBitmap(bitmap,null,new RectF(x,top,x+w,top+h),p);
    }
    private void totalsBlock(){
        room(215);
        float left=265;
        rect(left,y-8,RIGHT,y+189,PALE);
        row("Blinds subtotal",money(n(totals,"subtotal")),left+13,y+12,false);y+=23;
        row("Installation / delivery",money(n(totals,"installation")),left+13,y+12,false);y+=23;
        row("Discount","−"+money(n(totals,"discount")),left+13,y+12,false);y+=23;
        row("Tax",money(n(totals,"tax")),left+13,y+12,false);y+=27;
        line(left+12,y-7,RIGHT-12,y-7,GOLD,1);
        row("TOTAL CAD",money(n(totals,"total")),left+13,y+13,true);y+=31;
        row("Deposit requested",money(n(totals,"deposit")),left+13,y+12,false);y+=23;
        row("Balance after deposit",money(n(totals,"remaining")),left+13,y+12,true);y+=20;
    }
    private void row(String label,String value,float x,float baseline,boolean bold){
        text(label,x,baseline,bold?11:9,bold?GREEN:MUTED,bold);
        rightText(value,RIGHT-10,baseline,bold?11:9,bold?GREEN:INK,bold);
    }
}
