package ca.albertaprime.blinds;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Alberta Prime Blinds: native Android camera, PDF save, and print handlers. */
public class MainActivity extends Activity {
    private static final int PICK_PICTURE = 1001;
    private static final int SAVE_BACKUP = 1002;
    private static final int SAVE_PDF = 1003;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private Uri cameraUri;
    private String pendingBackup;
    private byte[] pendingPdf;

    @SuppressWarnings("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4,42,37));
        getWindow().setNavigationBarColor(Color.rgb(4,42,37));
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest request){
                Uri uri=request.getUrl();
                if(uri.toString().startsWith("file:///android_asset/"))return false;
                try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}
                catch(Exception e){Toast.makeText(MainActivity.this,"Cannot open link",Toast.LENGTH_SHORT).show();}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> result,FileChooserParams params){
                if(chooser!=null)chooser.onReceiveValue(null);
                chooser=result;
                try{
                    Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] types=params.getAcceptTypes();
                    boolean image=types==null||types.length==0||types[0]==null||types[0].isEmpty()||types[0].startsWith("image/");
                    pick.setType(image?"image/*":"application/json");
                    if(!image){startActivityForResult(pick,PICK_PICTURE);return true;}
                    File picture=File.createTempFile("prime_photo_",".jpg",getCacheDir());
                    cameraUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",picture);
                    Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);
                    camera.setClipData(ClipData.newRawUri("photo",cameraUri));
                    camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if(params.isCaptureEnabled()){
                        try{startActivityForResult(camera,PICK_PICTURE);}
                        catch(ActivityNotFoundException e){cameraUri=null;startActivityForResult(pick,PICK_PICTURE);}
                    }else{
                        Intent both=Intent.createChooser(pick,"Camera or gallery");
                        both.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera});
                        startActivityForResult(both,PICK_PICTURE);
                    }
                }catch(Exception e){
                    if(chooser!=null)chooser.onReceiveValue(null);
                    chooser=null;
                    Toast.makeText(MainActivity.this,"Cannot open camera/gallery",Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void saveQuotePdf(String quoteJson,String name){
                prepareQuotePdf(quoteJson,name,false);
            }
            @JavascriptInterface public void printQuotePdf(String quoteJson,String name){
                prepareQuotePdf(quoteJson,name,true);
            }
            // For any older web code, keep a visible failure instead of a silent no-op.
            @JavascriptInterface public void printQuoteHtml(String html,String name,boolean pdf){
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Please update the quotation app assets",Toast.LENGTH_LONG).show());
            }
            @JavascriptInterface public void saveBackup(String name,String json){
                runOnUiThread(()->{
                    pendingBackup=json;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE,name);
                    startActivityForResult(intent,SAVE_BACKUP);
                });
            }
        },"AndroidApp");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void prepareQuotePdf(String json,String requestedName,boolean forPrinter){
        final String cleanName=safeFileName(requestedName)+".pdf";
        runOnUiThread(()->Toast.makeText(this,"Preparing quotation PDF...",Toast.LENGTH_SHORT).show());
        new Thread(()->{
            try{
                byte[] data=QuotePdfWriter.create(this,json);
                runOnUiThread(()->{
                    if(forPrinter)showPrintOptions(cleanName,data);
                    else openPdfSavePicker(cleanName,data);
                });
            }catch(Exception ex){
                Log.e("PrimePdf","PDF creation failed",ex);
                runOnUiThread(()->Toast.makeText(this,"PDF error: "+ex.getMessage(),Toast.LENGTH_LONG).show());
            }
        },"Prime-PDF-Renderer").start();
    }

    private String safeFileName(String proposed){
        String s=(proposed==null||proposed.isEmpty()?"Alberta_Prime_Quotation":proposed);
        s=s.replaceAll("[^a-zA-Z0-9_. -]","_");
        if(s.endsWith(".pdf"))s=s.substring(0,s.length()-4);
        return s;
    }

    private void openPdfSavePicker(String name,byte[] pdf){
        pendingPdf=pdf;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE,name);
        try{startActivityForResult(intent,SAVE_PDF);}
        catch(ActivityNotFoundException e){Toast.makeText(this,"File saving is unavailable",Toast.LENGTH_LONG).show();}
    }

    private void showPrintOptions(String name,byte[] pdf){
        new AlertDialog.Builder(this)
          .setTitle("Print quotation")
          .setItems(new String[]{"Android Print dialog","Open PDF in viewer, then Print"},(dialog,which)->{
              if(which==0)printNativePdf(name,pdf);
              else openPdfViewer(name,pdf);
          })
          .setNegativeButton("Cancel",null)
          .show();
    }

    private void openPdfViewer(String name,byte[] pdf){
        try{
            File target=new File(getCacheDir(),"prime_quotation_view.pdf");
            try(FileOutputStream out=new FileOutputStream(target)){out.write(pdf);}
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",target);
            Intent view=new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri,"application/pdf");
            view.setClipData(ClipData.newRawUri("PDF",uri));
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(view,"Open PDF to print"));
        }catch(Exception ex){
            Toast.makeText(this,"PDF viewer unavailable: "+ex.getMessage(),Toast.LENGTH_LONG).show();
            openPdfSavePicker(name,pdf);
        }
    }

    private void printNativePdf(String name,byte[] bytes){
        try{
            PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
            if(manager==null)throw new Exception("Android Print is unavailable");
            PrintDocumentAdapter adapter=new PrintDocumentAdapter(){
                @Override public void onLayout(PrintAttributes oldAttrs,PrintAttributes newAttrs,
                        CancellationSignal cancel,LayoutResultCallback callback,Bundle extra){
                    if(cancel.isCanceled()){callback.onLayoutCancelled();return;}
                    PrintDocumentInfo info=new PrintDocumentInfo.Builder(name)
                          .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                          .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build();
                    callback.onLayoutFinished(info,true);
                }
                @Override public void onWrite(PageRange[] pages,ParcelFileDescriptor destination,
                        CancellationSignal cancel,WriteResultCallback callback){
                    if(cancel.isCanceled()){callback.onWriteCancelled();return;}
                    try(FileOutputStream out=new FileOutputStream(destination.getFileDescriptor())){
                        out.write(bytes);
                        out.flush();
                        callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                    }catch(Exception ex){callback.onWriteFailed("PDF could not be sent to printer");}
                }
            };
            PrintAttributes attrs=new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
            manager.print(name,adapter,attrs);
        }catch(Exception ex){
            Log.e("PrimePrint","Print failed",ex);
            Toast.makeText(this,"Print unavailable; opening PDF viewer",Toast.LENGTH_LONG).show();
            openPdfViewer(name,bytes);
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_PICTURE){
            if(chooser!=null){
                Uri uri=null;
                if(resultCode==RESULT_OK){
                    if(data!=null&&data.getData()!=null)uri=data.getData();
                    else if(cameraUri!=null)uri=cameraUri;
                }
                chooser.onReceiveValue(uri==null?null:new Uri[]{uri});
                chooser=null;cameraUri=null;
            }
        }else if(requestCode==SAVE_BACKUP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Cannot open destination");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup saved",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"Backup save failed",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }else if(requestCode==SAVE_PDF){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingPdf!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Cannot open PDF destination");
                    out.write(pendingPdf);
                    out.flush();
                    Toast.makeText(this,"PDF saved successfully",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"PDF save failed: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }
            pendingPdf=null;
        }
    }
    @Override public void onBackPressed(){
        web.evaluateJavascript("window.albertaBack ? window.albertaBack() : false",value->{
            if("false".equals(value))finish();
        });
    }
    @Override protected void onDestroy(){
        if(web!=null)web.destroy();
        super.onDestroy();
    }
}
