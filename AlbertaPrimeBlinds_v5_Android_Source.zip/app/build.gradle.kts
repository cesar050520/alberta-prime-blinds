plugins { id("com.android.application") }

android {
    namespace = "ca.albertaprime.blinds"
    compileSdk = 35
    defaultConfig {
        applicationId = "ca.albertaprime.blinds"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "5.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("androidx.core:core:1.15.0")
}
