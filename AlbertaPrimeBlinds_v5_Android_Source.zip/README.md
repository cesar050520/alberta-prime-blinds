# Alberta Prime Blinds v5 (Print/PDF compile fix)

This APK project fixes compilation errors from the v4 direct PDF callback attempt by using Android's built-in PrintManager for both printing and PDF export. The quotation WebView is attached to a FrameLayout *behind* the main app so the print renderer can lay out the quotation. It retains photo upload, backup, products and orders.

**Print:** tap Print then choose printer from Android print screen.
**Save PDF:** tap Save PDF, select **Save as PDF** from Android print screen, then tap the PDF Save icon and select a folder.

This is a **source project**, not an APK. Android installation and PDF output still require on-device testing. The app's package ID and storage ID are unchanged. Back up your data before replacing an APK signed by a different key.

To build from a ZIP uploaded to GitHub, the workflow needs:

    - name: Extract Android project
      run: unzip -q AlbertaPrimeBlinds_v5_Android_Source.zip -d android

Build using Gradle 8.9 / Android API 35.
